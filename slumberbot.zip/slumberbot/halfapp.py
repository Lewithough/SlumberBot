# /index.py

#Import libraries
from flask import Flask, request, jsonify, render_template, current_app
import datetime, base64, os, requests, json, random, cherrypy, csv
import gather_keys_oauth2 as Oauth2
import pandas as pd 
import fitbit, dialogflow, pusher 
from cryptography.fernet import Fernet
from simplekv.fs import FilesystemStore 

from slumber_bot.speech import sleep_speech, stage_speech


'''Flask App Factory Function'''
app = Flask(__name__)
# config_file = 'slumber_bot/config.py'
# app.config.from_pyfile(config_file)

#Omit authorize      
@app.route('/')
def index():
  return render_template('index.html')

# run Flask app
if __name__ == "__main__":
    app.run()

with open('sleepSummary-2019-11-20.csv', mode='r') as csv_summary:
    csv_reader = csv.DictReader(csv_summary)
    for row in csv_reader:
        sleepDuration = row["Minutes Asleep"]
        durationHour = int(int(sleepDuration)/60)
        durationMinute = int(sleepDuration) - 60*durationHour
        startTime = row["StartTime"].split("T")[1]
        startHour = startTime.split(":")[0]
        startMinute = startTime.split(":")[1]
        endTime = row["EndTime"].split("T")[1]
        endHour = endTime.split(":")[0]
        endMinute = endTime.split(":")[1]
        awakeTime = row["Awake Duration"]

def get_sleep():
  speech = "Last night you got {durationHour} hours and {durationHour} minutes of sleep. You fell asleep at {durationHour}:{durationHour]}. Did you want to here your sleep stages?"
  return speech

print(get_sleep())

@app.route('/get_sleep_question', methods=['POST'])
def get_sleep_question():
    print('1')
    data = request.get_json(silent=True)
    response = get_sleep()
    reply = {
        "fulfillmentText": response,
    }

    return jsonify(reply)


