from flask import Flask, request, render_template, current_app

app = Flask(__name__)

@app.route('/')
def index():
  return render_template('index.html')

# run Flask app
if __name__ == "__main__":
  app.run()

@app.route('/register', methods=['GET', 'POST'])
def register():
  if request.method == 'GET':
    print('1')
    verify = request.values.get('verify')
    print(verify)
    if verify == 'c8dfd2e0a2ca65fcb106bd2c95156e0f0421df2949390045b27a497264ea899f':
      return ('', 204)
    else: 
      abort(404)