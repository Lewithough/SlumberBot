# /index.py

#Import libraries
from flask import Flask, request, jsonify, render_template, current_app
from flask_caching import Cache
from google.protobuf import struct_pb2
import datetime, base64, os, requests, json, random, cherrypy, csv
import gather_keys_oauth2 as Oauth2
import pandas as pd 
import fitbit, dialogflow

from slumber_bot.auth import get_sleep_TEST, get_sleep_A, get_sleep_B, get_sleep_C, get_sleep_D, get_sleep_E

dialog_step = '0'

# Data Foundry Set-up:
# API endpoint
URL = "https://data.id.tue.nl/datasets/entity/249/item/"
# use dict for headers to be sent to the API
HEADERS = {
  'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
  'resource_id':'y.liu10@student.tue.nl',
  'token': 'lyz95416'
}

'''Flask App Factory Function'''
app = Flask(__name__)
     
@app.route('/')
def index():
  return render_template('index.html')

# run Flask app
if __name__ == "__main__":
  app.run()

# Read the data (one time per day)
today = str(datetime.datetime.now().strftime("%Y-%m-%d"))
# today = "2020-05-05"
oneday = "2020-05-05" #2019-11-20
otherday = "2020-05-11" #2019-11-20
date = today

readdatedf = pd.read_csv('DateSave.csv')
read_date_A = str(readdatedf.at[0,'A-Date'])
read_date_B = str(readdatedf.at[0,'B-Date'])
read_date_C = str(readdatedf.at[0,'C-Date'])
read_date_D = str(readdatedf.at[0,'D-Date'])
read_date_E = str(readdatedf.at[0,'E-Date'])

get_number = [] #could be customized ['A','B','C','D','E']

# # read the data only for the first time of a day:
# if date != read_date: TAB
# sleep_log_TEST, sleep_sum_TEST = get_sleep_TEST(date) //data already saved.

#A:
if read_date_A != date:
  if 'A' in get_number:
    sleep_log_A, sleep_sum_A = get_sleep_A(date)

    """Save sleep log A"""
    stime_list_A = []
    sval_list_A = []

    for i in sleep_log_A['sleep'][0]['minuteData']:
      stime_list_A.append(i['dateTime'])
      sval_list_A.append(i['value'])
        
    sleepdf_A = pd.DataFrame({'State':sval_list_A,'Time':stime_list_A})
    sleepdf_A['Interpreted'] = sleepdf_A['State'].map({'2':'Awake','3':'Very Awake','1':'Asleep'})
    sleepdf_A.to_csv('sleepLog-' + 'A-' + date + '.csv', columns = ['Time','State','Interpreted'], header=True, index = False)

    """Sleep Summary A"""
    ssummarydf_A = pd.DataFrame({'Date':sleep_sum_A['dateOfSleep'], 'MainSleep':sleep_sum_A['isMainSleep'], \
                               'Duration':sleep_sum_A['duration'], 'Efficiency':sleep_sum_A['efficiency'], \
                               'StartTime':sleep_sum_A['startTime'], 'EndTime':sleep_sum_A['endTime'], \
                               'Minutes Asleep':sleep_sum_A['minutesAsleep'], 'Time in Bed':sleep_sum_A['timeInBed'], \
                               'Awakes':sleep_sum_A['awakeCount'], 'Awake Duration':sleep_sum_A['awakeDuration'], \
                               'Awakenings':sleep_sum_A['awakeningsCount'], 'Awakenings Duration':sleep_sum_A['minutesAwake'], \
                               'Restless Count':sleep_sum_A['restlessCount'], 'Restless Duration':sleep_sum_A['restlessDuration']} ,index=[0])

    ssummarydf_A.to_csv('sleepSummary-' + 'A-' + date + '.csv', \
                     columns = ['Date', 'MainSleep', 'Duration', 'Efficiency', 'StartTime', 'EndTime', 'Minutes Asleep', 'Time in Bed', \
                                'Awakes', 'Awake Duration', 'Awakenings', 'Awakenings Duration', \
                                'Restless Count', 'Restless Duration'], header=True, index=False)

    #Save the date data

    read_date = pd.read_csv('DateSave.csv')
    read_date[u'A-Date'] = str(date)
    read_date.to_csv('DateSave.csv', mode='w+', header=True, index=False)

    sleepsummarydf_A = pd.read_csv('sleepSummary-' + 'A-' + date + '.csv')
elif read_date_A == date:
  sleepsummarydf_A = pd.read_csv('sleepSummary-' + 'A-' + date + '.csv')
  print('get sleepsummarydf_A')

#B:
if read_date_B != date:
  if 'B' in get_number:
    sleep_log_B, sleep_sum_B = get_sleep_B(date)

    """Save sleep log B"""
    stime_list_B = []
    sval_list_B = []

    for i in sleep_log_B['sleep'][0]['minuteData']:
      stime_list_B.append(i['dateTime'])
      sval_list_B.append(i['value'])
        
    sleepdf_B = pd.DataFrame({'State':sval_list_B,'Time':stime_list_B})
    sleepdf_B['Interpreted'] = sleepdf_B['State'].map({'2':'Awake','3':'Very Awake','1':'Asleep'})
    sleepdf_B.to_csv('sleepLog-' + 'B-' + date + '.csv', columns = ['Time','State','Interpreted'], header=True, index = False)

    """Sleep Summary B"""
    ssummarydf_B = pd.DataFrame({'Date':sleep_sum_B['dateOfSleep'], 'MainSleep':sleep_sum_B['isMainSleep'], \
                               'Duration':sleep_sum_B['duration'], 'Efficiency':sleep_sum_B['efficiency'], \
                               'StartTime':sleep_sum_B['startTime'], 'EndTime':sleep_sum_B['endTime'], \
                               'Minutes Asleep':sleep_sum_B['minutesAsleep'], 'Time in Bed':sleep_sum_B['timeInBed'], \
                               'Awakes':sleep_sum_B['awakeCount'], 'Awake Duration':sleep_sum_B['awakeDuration'], \
                               'Awakenings':sleep_sum_B['awakeningsCount'], 'Awakenings Duration':sleep_sum_B['minutesAwake'], \
                               'Restless Count':sleep_sum_B['restlessCount'], 'Restless Duration':sleep_sum_B['restlessDuration']} ,index=[0])

    ssummarydf_B.to_csv('sleepSummary-' + 'B-' + date + '.csv', \
                     columns = ['Date', 'MainSleep', 'Duration', 'Efficiency', 'StartTime', 'EndTime', 'Minutes Asleep', 'Time in Bed', \
                                'Awakes', 'Awake Duration', 'Awakenings', 'Awakenings Duration', \
                                'Restless Count', 'Restless Duration'], header=True, index=False)

    #Save the date data
    read_date = pd.read_csv('DateSave.csv')
    read_date[u'B-Date'] = str(date)
    read_date.to_csv('DateSave.csv', mode='w+', header=True, index=False)

    sleepsummarydf_B = pd.read_csv('sleepSummary-' + 'B-' + date + '.csv')
    print('get sleepsummarydf_B')
elif read_date_B == date:
  sleepsummarydf_B = pd.read_csv('sleepSummary-' + 'B-' + date + '.csv')
  print('get sleepsummarydf_B')

#C:
if read_date_C != date:
  if 'C' in get_number:
    sleep_log_C, sleep_sum_C = get_sleep_C(date)

    """Save sleep log C"""
    stime_list_C = []
    sval_list_C = []

    for i in sleep_log_C['sleep'][0]['minuteData']:
      stime_list_C.append(i['dateTime'])
      sval_list_C.append(i['value'])
        
    sleepdf_C = pd.DataFrame({'State':sval_list_C,'Time':stime_list_C})
    sleepdf_C['Interpreted'] = sleepdf_C['State'].map({'2':'Awake','3':'Very Awake','1':'Asleep'})
    sleepdf_C.to_csv('sleepLog-' + 'C-' + date + '.csv', columns = ['Time','State','Interpreted'], header=True, index = False)

    """Sleep Summary C"""
    ssummarydf_C = pd.DataFrame({'Date':sleep_sum_C['dateOfSleep'], 'MainSleep':sleep_sum_C['isMainSleep'], \
                               'Duration':sleep_sum_C['duration'], 'Efficiency':sleep_sum_C['efficiency'], \
                               'StartTime':sleep_sum_C['startTime'], 'EndTime':sleep_sum_C['endTime'], \
                               'Minutes Asleep':sleep_sum_C['minutesAsleep'], 'Time in Bed':sleep_sum_C['timeInBed'], \
                               'Awakes':sleep_sum_C['awakeCount'], 'Awake Duration':sleep_sum_C['awakeDuration'], \
                               'Awakenings':sleep_sum_C['awakeningsCount'], 'Awakenings Duration':sleep_sum_C['minutesAwake'], \
                               'Restless Count':sleep_sum_C['restlessCount'], 'Restless Duration':sleep_sum_C['restlessDuration']} ,index=[0])

    ssummarydf_C.to_csv('sleepSummary-' + 'C-' + date + '.csv', \
                     columns = ['Date', 'MainSleep', 'Duration', 'Efficiency', 'StartTime', 'EndTime', 'Minutes Asleep', 'Time in Bed', \
                                'Awakes', 'Awake Duration', 'Awakenings', 'Awakenings Duration', \
                                'Restless Count', 'Restless Duration'], header=True, index=False)

    #Save the date data
    read_date = pd.read_csv('DateSave.csv')
    read_date[u'C-Date'] = str(date)
    read_date.to_csv('DateSave.csv', mode='w+', header=True, index=False)

    sleepsummarydf_C = pd.read_csv('sleepSummary-' + 'C-' + date + '.csv')
elif read_date_C == date:
  sleepsummarydf_C = pd.read_csv('sleepSummary-' + 'C-' + date + '.csv')
  print('get sleepsummarydf_C')

#D:
if read_date_D != date:
  if 'D' in get_number:
    sleep_log_D, sleep_sum_D = get_sleep_D(date)

    """Save sleep log D"""
    stime_list_D = []
    sval_list_D = []

    for i in sleep_log_D['sleep'][0]['minuteData']:
      stime_list_D.append(i['dateTime'])
      sval_list_D.append(i['value'])
        
    sleepdf_D = pd.DataFrame({'State':sval_list_D,'Time':stime_list_D})
    sleepdf_D['Interpreted'] = sleepdf_D['State'].map({'2':'Awake','3':'Very Awake','1':'Asleep'})
    sleepdf_D.to_csv('sleepLog-' + 'D-' + date + '.csv', columns = ['Time','State','Interpreted'], header=True, index = False)

    """Sleep Summary D"""
    ssummarydf_D = pd.DataFrame({'Date':sleep_sum_D['dateOfSleep'], 'MainSleep':sleep_sum_D['isMainSleep'], \
                               'Duration':sleep_sum_D['duration'], 'Efficiency':sleep_sum_D['efficiency'], \
                               'StartTime':sleep_sum_D['startTime'], 'EndTime':sleep_sum_D['endTime'], \
                               'Minutes Asleep':sleep_sum_D['minutesAsleep'], 'Time in Bed':sleep_sum_D['timeInBed'], \
                               'Awakes':sleep_sum_D['awakeCount'], 'Awake Duration':sleep_sum_D['awakeDuration'], \
                               'Awakenings':sleep_sum_D['awakeningsCount'], 'Awakenings Duration':sleep_sum_D['minutesAwake'], \
                               'Restless Count':sleep_sum_D['restlessCount'], 'Restless Duration':sleep_sum_D['restlessDuration']} ,index=[0])

    ssummarydf_D.to_csv('sleepSummary-' + 'D-' + date + '.csv', \
                     columns = ['Date', 'MainSleep', 'Duration', 'Efficiency', 'StartTime', 'EndTime', 'Minutes Asleep', 'Time in Bed', \
                                'Awakes', 'Awake Duration', 'Awakenings', 'Awakenings Duration', \
                                'Restless Count', 'Restless Duration'], header=True, index=False)

    #Save the date data
    read_date = pd.read_csv('DateSave.csv')
    read_date[u'D-Date'] = str(date)
    read_date.to_csv('DateSave.csv', mode='w+', header=True, index=False)

    sleepsummarydf_D = pd.read_csv('sleepSummary-' + 'D-' + date + '.csv')
elif read_date_D == date:
  sleepsummarydf_D = pd.read_csv('sleepSummary-' + 'D-' + date + '.csv')
  print('get sleepsummarydf_D')

#E:
if read_date_E != date:
  if 'E' in get_number:
    sleep_log_E, sleep_sum_E = get_sleep_E(date)

    """Save sleep log E"""
    stime_list_E = []
    sval_list_E = []

    for i in sleep_log_E['sleep'][0]['minuteData']:
      stime_list_E.append(i['dateTime'])
      sval_list_E.append(i['value'])
        
    sleepdf_E = pd.DataFrame({'State':sval_list_E,'Time':stime_list_E})
    sleepdf_E['Interpreted'] = sleepdf_E['State'].map({'2':'Awake','3':'Very Awake','1':'Asleep'})
    sleepdf_E.to_csv('sleepLog-' + 'E-' + date + '.csv', columns = ['Time','State','Interpreted'], header=True, index = False)

    """Sleep Summary E"""
    ssummarydf_E = pd.DataFrame({'Date':sleep_sum_E['dateOfSleep'], 'MainSleep':sleep_sum_E['isMainSleep'], \
                               'Duration':sleep_sum_E['duration'], 'Efficiency':sleep_sum_E['efficiency'], \
                               'StartTime':sleep_sum_E['startTime'], 'EndTime':sleep_sum_E['endTime'], \
                               'Minutes Asleep':sleep_sum_E['minutesAsleep'], 'Time in Bed':sleep_sum_E['timeInBed'], \
                               'Awakes':sleep_sum_E['awakeCount'], 'Awake Duration':sleep_sum_E['awakeDuration'], \
                               'Awakenings':sleep_sum_E['awakeningsCount'], 'Awakenings Duration':sleep_sum_E['minutesAwake'], \
                               'Restless Count':sleep_sum_E['restlessCount'], 'Restless Duration':sleep_sum_E['restlessDuration']} ,index=[0])

    ssummarydf_E.to_csv('sleepSummary-' + 'E-' + date + '.csv', \
                     columns = ['Date', 'MainSleep', 'Duration', 'Efficiency', 'StartTime', 'EndTime', 'Minutes Asleep', 'Time in Bed', \
                                'Awakes', 'Awake Duration', 'Awakenings', 'Awakenings Duration', \
                                'Restless Count', 'Restless Duration'], header=True, index=False)

    #Save the date data
    read_date = pd.read_csv('DateSave.csv')
    read_date[u'E-Date'] = str(date)
    read_date.to_csv('DateSave.csv', mode='w+', header=True, index=False)

    sleepsummarydf_E = pd.read_csv('sleepSummary-' + 'E-' + date + '.csv')
elif read_date_E == date:
  sleepsummarydf_E = pd.read_csv('sleepSummary-' + 'E-' + date + '.csv')
  print('get sleepsummarydf_E')
sleepsummarydf_TEST = pd.read_csv('sleepSummary-' + 'A-' + otherday + '.csv') #could be changed as one day.


#inbed_time
inbed_hour = [1, 1, 0, 0, 2, 23]
inbed_minute = [30, 10, 30, 30, 00, 30]

#initialize
# stepdf = pd.DataFrame({'dialog_step_value':'1.1'} ,index=[0])
# stepdf.to_csv('step.csv', columns = ['dialog_step_value'], header=True, index=False)

stepdf = pd.DataFrame({'2941725442515722':'1-1', '2741133325984300':'1-1', '3288915487803212':'1-1', '2955503917870027':'1-1', '3376883239008233':'1-1', '3781201318618542':'1-1','3059608007493454':'1-1'} ,index=[0])
stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/get_sleep_question', methods=['POST'])
@cache.cached(timeout=3)
def get_sleep_question():
  # dialog_step = 1-1
  data = request.get_json(silent=True)
  print(data)

  #get action from data
  if 'originalDetectIntentRequest' in data:
    if 'payload' in data['originalDetectIntentRequest']:
      if 'data' in data['originalDetectIntentRequest']['payload']:
        if 'sender' in data['originalDetectIntentRequest']['payload']['data']:
          if 'id' in data['originalDetectIntentRequest']['payload']['data']['sender']:
            sender_id = data['originalDetectIntentRequest']['payload']['data']['sender']['id']
          else: sender_id = 0
        else: sender_id = 0
      else: sender_id = 0
    else: sender_id = 0
  else: sender_id = 0
  print(sender_id)

  if 'queryResult' in data:
    if 'queryText' in data['queryResult']:
      query = data['queryResult']['queryText']
    else: query = 0
  else: query = 0

  # dialog_step = '0'
  # with open('step.csv', mode='r') as csv_step:
  #   csv_reader = csv.DictReader(csv_step)
  #   for row in csv_reader:
  #     dialog_step = row[sender_id]
  #     print(dialog_step)

  stepdf = pd.read_csv('step.csv')
  dialog_step = str(stepdf.at[0, sender_id])
  print(dialog_step)
  all_step_TESTA = str(stepdf.at[0, '2941725442515722'])
  all_step_TESTB = str(stepdf.at[0, '2741133325984300'])
  all_step_A = str(stepdf.at[0, '3288915487803212'])
  all_step_B = str(stepdf.at[0, '2955503917870027'])
  all_step_C = str(stepdf.at[0, '3376883239008233'])
  all_step_D = str(stepdf.at[0, '3781201318618542'])
  all_step_E = str(stepdf.at[0, '3059608007493454'])


  # avoid multiple user-cases:
  if sender_id == "3288915487803212":
    if all_step_B != '1-1' or all_step_C != '1-1' or all_step_D != '1-1' or all_step_E != '1-1':
      dialog_step = '5-1'
      stepdf.at[0, sender_id] = '5-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
  if sender_id == "2955503917870027":
    if all_step_A != '1-1' or all_step_C != '1-1' or all_step_D != '1-1' or all_step_E != '1-1':
      dialog_step = '5-1'
      stepdf.at[0, sender_id] = '5-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
  if sender_id == "3376883239008233":
    if all_step_A != '1-1' or all_step_B != '1-1' or all_step_D != '1-1' or all_step_E != '1-1':
      dialog_step = '5-1'
      stepdf.at[0, sender_id] = '5-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
  if sender_id == "3781201318618542":
    if all_step_A != '1-1' or all_step_B != '1-1' or all_step_C != '1-1' or all_step_E != '1-1':
      dialog_step = '5-1'
      stepdf.at[0, sender_id] = '5-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
  if sender_id == "3059608007493454":
    if all_step_A != '1-1' or all_step_B != '1-1' or all_step_C != '1-1' or all_step_D != '1-1':
      dialog_step = '5-1'
      stepdf.at[0, sender_id] = '5-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)


  reply = {}
  # # Category I - sleep quality - 1
  if dialog_step == '1-1':
    if sender_id == "2941725442515722":
      username = "Yizhou"
    if sender_id == "2741133325984300": #SanSan: 3099351093516345 #Yizhou: 2741133325984300
      username = "Yizhou"
    if sender_id == "3288915487803212":
      username = "Yawei"
    if sender_id == "2955503917870027":
      username = "Xiaoyu"
    if sender_id == "3376883239008233":
      username = "Sark"
    if sender_id == "3781201318618542":
      username = "Yunjie"
    if sender_id == "3059608007493454":
      username = "Jingcai"

    if query == 'Good morning!' or query == 'good morning!' or query == 'good morning' or query == 'Good morning' or query == 'goodmorning' or query == 'Goodmorning':
      reply = {
        "followupEventInput": {
          "name": "sleep-quality-1-1",
          "languageCode": "en-US",
          "parameters": {
            "user_name": username,
          }
        }
      }
      stepdf.at[0, sender_id] = '1-2'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'pp1': username} 
      r_post = requests.post(url = URL, headers= HEADERS, json = PARAMS)


  if dialog_step == '1-2':
    if query == 'Very good' or query == 'Good' or query == 'Fair':
      reply = {
      "followupEventInput": {
        "name": "sleep-quality-1-2",
        "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '1-4'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

    elif query == 'Bad' or query == 'Very bad':
      #skip 1.2
      dialog_step = '1-3'
      stepdf.at[0, sender_id] = '1-3'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

    if query == 'Very good':
      PARAMS = {'sleep_score': "5"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == 'Good':      
      PARAMS = {'sleep_score': "4"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == 'Fair':      
      PARAMS = {'sleep_score': "3"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == 'Bad':      
      PARAMS = {'sleep_score': "2", "physical_refresh":"1"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == 'Very bad':      
      PARAMS = {'sleep_score': "1", "physical_refresh":"1"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)


  if dialog_step == '1-3':
    reply = {
    "followupEventInput": {
      "name": "sleep-quality-1-3",
      "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-1'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)


  if dialog_step == '1-4':
    print("what?")
    if query == 'Fatigued':
      reply = {
      "followupEventInput": {
        "name": "sleep-quality-1-4",
        "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '2-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

    elif query == "Yes, I'm refreshed" or query == 'Somewhat refreshed':
      #skip 1.4
      dialog_step = '2-1'
      stepdf.at[0, sender_id] = '2-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

    if query == "Yes, I'm refreshed":      
      PARAMS = {'physical_refresh': "5"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == 'Somewhat refreshed':      
      PARAMS = {'physical_refresh': "3"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == 'Fatigued':      
      PARAMS = {'physical_refresh': "1"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)


  if dialog_step == '2-1':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-1",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-2'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    if query != "Yes, I'm refreshed" and query != 'Somewhat refreshed':
      PARAMS = {'factor-sleep_quality': query} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)


  if dialog_step == '2-2':
    # awakes = int(sleep_sum_A['awakeCount'])
    if sender_id == "2941725442515722":
      awakes = int(sleepsummarydf_TEST.at[0,'Awakes'])
    if sender_id == "2741133325984300":
      awakes = int(sleepsummarydf_TEST.at[0,'Awakes'])
    if sender_id == "3288915487803212":
      awakes = int(sleepsummarydf_A.at[0,'Awakes'])
    if sender_id == "2955503917870027":
      awakes = int(sleepsummarydf_B.at[0,'Awakes'])
    if sender_id == "3376883239008233":
      awakes = int(sleepsummarydf_C.at[0,'Awakes'])
    if sender_id == "3781201318618542":
      awakes = int(sleepsummarydf_D.at[0,'Awakes'])
    if sender_id == "3059608007493454":
      awakes = int(sleepsummarydf_E.at[0,'Awakes'])

    if query == "Yes, I can":
      if awakes == 0:
        reply = {
          "followupEventInput": {
            "name": "sleep-disorder-2-2",
            "languageCode": "en-US",
          }
        }
        stepdf.at[0, sender_id] = '2-4'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'awoke_or_not': "Yes"} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

      elif awakes > 0:
        reply = {
          "followupEventInput": {
            "name": "sleep-disorder-2-2",
            "languageCode": "en-US",
            "parameters":{
              "awakes": awakes,
            }
          }
        }
        stepdf.at[0, sender_id] = '2-4'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'awoke_or_not': "Yes", 'awakes':awakes} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "No, I can't remember":
      dialog_step = '2-3'
      stepdf.at[0, sender_id] = '2-3'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'awoke_or_not': "No", 'awakes':awakes} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "I didn't wake up":
      dialog_step = '2-5'
      stepdf.at[0, sender_id] = '2-5'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'Awoke_or_not': "Can't remember", 'awakes':awakes} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)


  if dialog_step == '2-3':
    # awakes = int(sleep_sum_A['awakeCount'])
    if sender_id == "2941725442515722":
      awakes = int(sleepsummarydf_TEST.at[0,'Awakes'])
    if sender_id == "2741133325984300":
      awakes = int(sleepsummarydf_TEST.at[0,'Awakes'])
    if sender_id == "3288915487803212":
      awakes = int(sleepsummarydf_A.at[0,'Awakes'])
    if sender_id == "2955503917870027":
      awakes = int(sleepsummarydf_B.at[0,'Awakes'])
    if sender_id == "3376883239008233":
      awakes = int(sleepsummarydf_C.at[0,'Awakes'])
    if sender_id == "3781201318618542":
      awakes = int(sleepsummarydf_D.at[0,'Awakes'])
    if sender_id == "3059608007493454":
      awakes = int(sleepsummarydf_E.at[0,'Awakes'])

    if awakes == 0:
      dialog_step = '2-5'
      stepdf.at[0, sender_id] = '2-5'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    elif awakes > 0:
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-3",
          "languageCode": "en-US",
          "parameters":{
            "awakes": awakes,
          }
        }
      }
      stepdf.at[0, sender_id] = '2-4-2'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

  if dialog_step == '2-4':
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-4",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '2-5'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'factor-awakenings': query} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-4-2':
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-4-2",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '2-5'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      if query != "No, not at all":
        PARAMS = {'factor-awakenings': query} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-5':
    bedtime_difference = 0
    inbedhour = 0
    inbedminute = 0
    if sender_id == "2941725442515722":
      starttime_hour = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[0]
      inbedminute = inbed_minute[0]
    if sender_id == "2741133325984300":
      starttime_hour = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[0]
      inbedminute = inbed_minute[0]
    if sender_id == "3288915487803212":
      starttime_hour = int(sleepsummarydf_A.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_A.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[1]
      inbedminute = inbed_minute[1]
    if sender_id == "2955503917870027":
      starttime_hour = int(sleepsummarydf_B.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_B.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[2]
      inbedminute = inbed_minute[2]
    if sender_id == "3376883239008233":
      starttime_hour = int(sleepsummarydf_C.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_C.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[3]
      inbedminute = inbed_minute[3]
    if sender_id == "3781201318618542":
      starttime_hour = int(sleepsummarydf_D.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_D.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[4]
      inbedminute = inbed_minute[4]
    if sender_id == "3059608007493454":
      starttime_hour = int(sleepsummarydf_E.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_E.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[5]
      inbedminute = inbed_minute[5]

    print(starttime_hour)
    print(inbedhour)
    if int(inbedhour) > 12 and int(starttime_hour) < 12:
      bedtime_difference = (int(starttime_hour)+24-int(inbedhour))*60+int(starttime_minute)-int(inbedminute)
    else:
      bedtime_difference = (int(starttime_hour)-int(inbedhour))*60+int(starttime_minute)-int(inbedminute)

    print(bedtime_difference)
    # bedtime_difference = 30 #for test

    if query == "Yes, It's hard" or query == "Yes, I do":
      PARAMS = {'hard_to_sleep_again': "Yes", "factor-awakenings-score": "4"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 
    elif query == "Not hard at all" or query == "No, I don't think so":
      PARAMS = {'hard_to_sleep_again': "No", "factor-awakenings-score": "2"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    # In any condition, the code will run until this line. 

    if query == "Yes, It's hard" or query == "Not hard at all" or query == "No, I can't remember" or query == "I didn't wake up" or query == "Yes, I do" or query == "No, I don't think so":
      if bedtime_difference >= 60:
        if starttime_hour >= 0 and starttime_hour <= 9:
          starttime_hour = '0' + str(starttime_hour)
        else:
          starttime_hour = str(starttime_hour)
        if starttime_minute >= 0 and starttime_minute <= 9:
          starttime_minute = '0' + str(starttime_minute) 
        else:
          starttime_minute = str(starttime_minute)
        reply = {
          "followupEventInput": {
            "name": "sleep-disorder-2-5",
            "languageCode": "en-US",
            "parameters":{
              "starttime_hour": starttime_hour,
              "starttime_minute": starttime_minute,
              "inbed_hour": inbedhour,
              "inbed_minute": inbedminute,
            }
          }
        }
        stepdf.at[0, sender_id] = '2-5-2' #'2-6'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'hard_to_sleep': "Yes", 'starttime_hour':starttime_hour, 'starttime_minute':starttime_minute} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
      elif bedtime_difference < 60:
        dialog_step = '2-9'
        print ("Yesyes")
        stepdf.at[0, sender_id] = '2-9'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'hard_to_sleep': "No", 'starttime_hour':starttime_hour, 'starttime_minute':starttime_minute} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-5-2':
    inbedhour = 0
    inbedminute = 0
    if sender_id == "2941725442515722":
      starttime_hour = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[0]
      inbedminute = inbed_minute[0]
    if sender_id == "2741133325984300":
      starttime_hour = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[0]
      inbedminute = inbed_minute[0]
    if sender_id == "3288915487803212":
      starttime_hour = int(sleepsummarydf_A.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_A.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[1]
      inbedminute = inbed_minute[1]
    if sender_id == "2955503917870027":
      starttime_hour = int(sleepsummarydf_B.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_B.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[2]
      inbedminute = inbed_minute[2]
    if sender_id == "3376883239008233":
      starttime_hour = int(sleepsummarydf_C.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_C.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[3]
      inbedminute = inbed_minute[3]
    if sender_id == "3781201318618542":
      starttime_hour = int(sleepsummarydf_D.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_D.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[4]
      inbedminute = inbed_minute[4]
    if sender_id == "3059608007493454":
      starttime_hour = int(sleepsummarydf_E.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_E.at[0, 'StartTime'].split('T')[1].split(':')[1])
      inbedhour = inbed_hour[5]
      inbedminute = inbed_minute[5]

    if (starttime_hour < 10):
      starttime_hour = '0'+ str(starttime_hour)
    if (starttime_minute < 10):
      starttime_minute = '0'+ str(starttime_minute)

    if query == "40 - 60 minutes" or query == "More than 60 minutes":
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-5-2",
          "languageCode": "en-US",
          "parameters":{
            "starttime_hour": starttime_hour,
            "starttime_minute": starttime_minute,
            "inbed_hour": inbedhour,
            "inbed_minute": inbedminute,
          }
        }
      }
      stepdf.at[0, sender_id] = '2-6'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'hard_to_sleep': "Yes"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "Less than 20 minutes" or query == "20 - 40 minutes":
      dialog_step = '2-9'
      stepdf.at[0, sender_id] = '2-9'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'hard_to_sleep': "No"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-6':
    if query == "No, it's my routine":
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-6",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '2-8'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    elif query == "Yes, it's difficult":
      dialog_step = '2-7'
      stepdf.at[0, sender_id] = '2-7'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)


  if dialog_step == '2-7':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-7",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-7-2' #used to be '2-8'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

  if dialog_step == '2-7-2':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-7-2",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-8-2'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    PARAMS = {'factor_primary-hard_sleep': query} 
    r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)


  if dialog_step == '2-8':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-8",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-9'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    PARAMS = {'inbed_routine': query} 
    r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-8-2':
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-8-2",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '2-9'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      if query != "No, I don't think so":
        PARAMS = {'factor_secondary-hard_sleep': query} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-9':
    threshold = 9    
    if sender_id == "2941725442515722":
      endtime_hour = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 9
    if sender_id == "2741133325984300":
      endtime_hour = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 9
    if sender_id == "3288915487803212":
      endtime_hour = int(sleepsummarydf_A.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_A.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 9
    if sender_id == "2955503917870027":
      endtime_hour = int(sleepsummarydf_B.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_B.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 8
    if sender_id == "3376883239008233":
      endtime_hour = int(sleepsummarydf_C.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_C.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 8
    if sender_id == "3781201318618542":
      endtime_hour = int(sleepsummarydf_D.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_D.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 9
    if sender_id == "3059608007493454":
      endtime_hour = int(sleepsummarydf_E.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_E.at[0, 'EndTime'].split('T')[1].split(':')[1])
      threshold = 9

    # endtime_hour = 5; #for test

    if query == "Positive affect":
      PARAMS = {'affect-hard_sleep_factor': "Positively", "inbed_routine-positive-score": "4"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 
    elif query == "Neutral affect":
      PARAMS = {'affect-hard_sleep_factor': "Neutrally", "inbed_routine-positive-score": "3"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "Negative affect":
      PARAMS = {'affect-hard_sleep_factor': "Negatively", "inbed_routine-score": "4"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "No, it didn't":
      PARAMS = {'affect-hard_sleep_factor': "Neutrally", "factor_primary-hard_sleep-score": "2", "factor_secondary-hard_sleep-score": "2"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "Yes, it did":
      PARAMS = {'affect-hard_sleep_factor': "Negatively", "factor_primary-hard_sleep-score": "4", "factor_secondary-hard_sleep-score": "4"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

    #add other possible responces

    if query =="Positive affect" or query == "Neutral affect" or query == "Negative affect" or query == 'Yes, it did' or query == "No, it didn't" or query == "Yes, It's hard" or query == "Not hard at all" or query == "No, I can't remember" or query == "I didn't wake up" or query == "Yes, I do" or query == "No, I don't think so" or query == "Less than 20 minutes" or query == "20 - 40 minutes":
      if endtime_hour < threshold: 
        if endtime_hour >= 0 and endtime_hour <= 9:
          endtime_hour = '0' + str(endtime_hour)
        else:
          endtime_hour = str(endtime_hour)
        if endtime_minute >= 0 and endtime_minute <= 9:
          endtime_minute = '0' + str(endtime_minute) 
        else:
          endtime_minute = str(endtime_minute)
        reply = {
          "followupEventInput": {
            "name": "sleep-disorder-2-9",
            "languageCode": "en-US",
            "parameters":{
              "endtime_hour": endtime_hour,
              "endtime_minute":endtime_minute,
            }
          }
        }
        stepdf.at[0, sender_id] = '2-9-2'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'get_up_earlier': "Yes", 'endtime_hour': endtime_hour, 'endtime_minute': endtime_minute} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
      elif endtime_hour >= threshold:
        dialog_step = '2-11'
        stepdf.at[0, sender_id] = '2-11'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'get_up_earlier': "No", 'endtime_hour': endtime_hour, 'endtime_minute': endtime_minute} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-9-2':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-9-2",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-10'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    if query != "Earlier slept" and query != "Just naturally woke up":
      PARAMS = {'factor_primary-get_up_earlier': query} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-10':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-10",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-11'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    if query != "No, I don't think so" and query != "Earlier slept":
      PARAMS = {'factor_secondary-get_up_earlier': query} 
      print(PARAMS)
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

  if dialog_step == '2-11':
    if sender_id == "2941725442515722":
      sleeptime = int(sleepsummarydf_TEST.at[0, 'Time in Bed'])
    if sender_id == "2741133325984300":
      sleeptime = int(sleepsummarydf_TEST.at[0, 'Time in Bed'])
    if sender_id == "3288915487803212":
      sleeptime = int(sleepsummarydf_A.at[0, 'Time in Bed'])
    if sender_id == "2955503917870027":
      sleeptime = int(sleepsummarydf_B.at[0, 'Time in Bed'])
    if sender_id == "3376883239008233":
      sleeptime = int(sleepsummarydf_C.at[0, 'Time in Bed'])
    if sender_id == "3781201318618542":
      sleeptime = int(sleepsummarydf_D.at[0, 'Time in Bed'])
    if sender_id == "3059608007493454":
      sleeptime = int(sleepsummarydf_E.at[0, 'Time in Bed'])

    # sleeptime = 400 #for test

    sleep_hour = int(sleeptime/60)
    print(sleep_hour)
    sleep_minute = int(sleeptime%60)
    print(sleep_minute)

    if query == "Yes, I feel tired":
      PARAMS = {'tired_or_not': "Yes", "factor_primary-get_up_earlier-score": "4", "factor_secondary-get_up_earlier-score": "3"} 
      print(PARAMS)
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 
    elif query == "No, I'm ok":
      PARAMS = {'tired_or_not': "No", "factor_primary-get_up_earlier-score": "2", "factor_secondary-get_up_earlier-score": "1"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

    if query == "Yes, It's hard" or query == "Not hard at all" or query == "Yes, I do" or query == "No, I don't think so" or query == "No, I can't remember" or query == "I didn't wake up" or query =="Positive affect" or query == "Neutral affect" or query == "Negative affect" or query == 'Yes, it did' or query == "No, it didn't" or query == "Less than 20 minutes" or query == "20 - 40 minutes":
      if sleeptime < 360:
        reply = {
          "followupEventInput": {
            "name": "sleep-disorder-2-11",
            "languageCode": "en-US",
            "parameters":{
              "sleep_hour": sleep_hour,
              "sleep_minute":sleep_minute,
            }
          }
        }
        stepdf.at[0, sender_id] = '2-12' #2-11-2
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'sleep_not_enough': "Yes", 'sleeptime': sleeptime} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 
      elif sleeptime >= 360:
        if query == "Yes, It's hard" or query == "Not hard at all" or query == "Yes, I do" or query == "No, I don't think so" or query == "No, I can't remember" or query == "I didn't wake up" or query == "Less than 20 minutes" or query == "20 - 40 minutes":
          dialog_step = '3-1'
          print("rua")
          stepdf.at[0, sender_id] = '3-1'
          stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
          PARAMS = {'sleep_not_enough': "No", 'sleeptime': sleeptime} 
          r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
        else:
          dialog_step = '4-1'
          stepdf.at[0, sender_id] = '4-1'
          stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
          PARAMS = {'sleep_not_enough': "No", 'sleeptime': sleeptime} 
          r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
      else:
        dialog_step = '4-1'
        stepdf.at[0, sender_id] = '4-1'
        stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
        PARAMS = {'sleep_not_enough': "No", 'sleeptime': sleeptime} 
        r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)  
    else:
      dialog_step = '4-1'
      stepdf.at[0, sender_id] = '4-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'sleep_not_enough': "No", 'sleeptime': sleeptime} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == '2-12':
    if query == "No, not enough":
      reply = {
        "followupEventInput": {
          "name": "sleep-disorder-2-12",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '2-12-2'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    elif query == "Yes, it's enough":
      print('yes not enough')
      dialog_step = '4-1'
      stepdf.at[0, sender_id] = '4-1'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'sleep_not_enough': "No"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == '2-12-2':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-12-2",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '2-13'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    PARAMS = {'factor_primary-sleep_not_enough': query} 
    r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == '2-13':
    reply = {
      "followupEventInput": {
        "name": "sleep-disorder-2-13",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '4-1'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    if query != "No, I don't think so":
      PARAMS = {'factor_secondary-sleep_not_enough': query} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == '3-1':
    if query == "Yes, It's hard" or query == "Not hard at all" or query == "No, I can't remember" or query == "I didn't wake up" or query == "Yes, I do" or query == "No, I don't think so" or query == "Less than 20 minutes" or query == "20 - 40 minutes":
      print("why")
      reply = {
        "followupEventInput": {
          "name": "good-sleep-3-1",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '3-2'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
      PARAMS = {'no_disorders': 'Yes'} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == '3-2':
    if query == "Yes, I did":
      reply = {
        "followupEventInput": {
          "name": "good-sleep-3-2",
          "languageCode": "en-US",
        }
      }
      stepdf.at[0, sender_id] = '3-3'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    elif query == "No, I did nothing":
      dialog_step = '3-4'
      print('3-4')
      stepdf.at[0, sender_id] = '3-4'
      stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

  if dialog_step == '3-3':
    reply = {
      "followupEventInput": {
        "name": "good-sleep-3-3",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '4-1'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    PARAMS = {'action_for_good_sleep': query} 
    r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == '3-4':
    reply = {
      "followupEventInput": {
        "name": "good-sleep-3-4",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '3-5'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

  if dialog_step == '3-5':
    reply = {
      "followupEventInput": {
        "name": "good-sleep-3-5",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '4-1'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)
    PARAMS = {'good_sleep_factor': "Keep a " + query} 
    r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 

  if dialog_step == "4-1":
    if sender_id == "2941725442515722":
      starttime_hour = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_TEST.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_TEST.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_TEST.at[0, 'Time in Bed'])
    if sender_id == "2741133325984300":
      starttime_hour = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_TEST.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_TEST.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_TEST.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_TEST.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_TEST.at[0, 'Time in Bed'])
    if sender_id == "3288915487803212":
      starttime_hour = int(sleepsummarydf_A.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_A.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_A.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_A.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_A.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_A.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_A.at[0, 'Time in Bed'])
    if sender_id == "2955503917870027":
      starttime_hour = int(sleepsummarydf_B.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_B.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_B.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_B.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_B.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_B.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_B.at[0, 'Time in Bed'])
    if sender_id == "3376883239008233":
      starttime_hour = int(sleepsummarydf_C.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_C.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_C.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_C.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_C.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_C.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_C.at[0, 'Time in Bed'])
    if sender_id == "3781201318618542":
      starttime_hour = int(sleepsummarydf_D.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_D.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_D.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_D.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_D.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_D.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_D.at[0, 'Time in Bed'])
    if sender_id == "3059608007493454":      
      starttime_hour = int(sleepsummarydf_E.at[0, 'StartTime'].split('T')[1].split(':')[0])
      starttime_minute = int(sleepsummarydf_E.at[0, 'StartTime'].split('T')[1].split(':')[1])
      endtime_hour = int(sleepsummarydf_E.at[0, 'EndTime'].split('T')[1].split(':')[0])
      endtime_minute = int(sleepsummarydf_E.at[0, 'EndTime'].split('T')[1].split(':')[1])
      restless_count = int(sleepsummarydf_E.at[0, 'Restless Count'])
      restless_duration = int(sleepsummarydf_E.at[0, 'Restless Duration'])
      sleeptime = int(sleepsummarydf_E.at[0, 'Time in Bed'])

    sleep_hour = int(sleeptime/60)
    sleep_minute = int(sleeptime%60)
    if (starttime_hour < 10):
      starttime_hour = '0'+ str(starttime_hour)
    if (starttime_minute < 10):
      starttime_minute = '0'+ str(starttime_minute)
    if (endtime_hour < 10):
      endtime_hour = '0'+ str(endtime_hour)
    if (endtime_minute < 10):
      endtime_minute = '0'+ str(endtime_minute)

    advice_0 = "You've slept " + str(sleep_hour) + " hours and " + str(sleep_minute) + " minutes last night. You fell asleep at " + str(starttime_hour) + ":" + str(starttime_minute) + " and woke up this morning at " + str(endtime_hour) + ":" + str(endtime_minute) +"." 

    if query == "Yes, I'm tired":
      PARAMS = {'tired_or_not': "Yes", "factor_primary-sleep_not_enough-score": "4", "factor_secondary-sleep_not_enough-score": "3"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS) 
    elif query == "No, I'm ok":
      PARAMS = {'tired_or_not': "No", "factor_primary-sleep_not_enough-score": "2", "factor_secondary-sleep_not_enough-score": "1"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "Yes, it works":
      PARAMS = {'action_works_or_not': "Yes", 'action_works_score': "4"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)       
    elif query == "Cannot tell":
      PARAMS = {'action_works_or_not': "Cannot tell", 'action_works_score': "3"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)
    elif query == "No, it doesn't":
      PARAMS = {'action_works_or_not': "No", 'action_works_score': "2"} 
      r_put = requests.put(url = URL, headers= HEADERS, json = PARAMS)

    #Read data from data foundry:
    r = requests.get(url = URL, headers= HEADERS, json = {})
    record = r.json()

    #First advice: 
    advice_1 = ""

    if 'factor-sleep_quality' in record:
      factor_sleep_quality = record['factor-sleep_quality']
      advice_1 = 'To sum up, ' + factor_sleep_quality.upper() + ' makes you feel bad this morning.'
    elif 'factor-sleep_quality' not in record:
      advice_1 = "In general, you had a good sleep last night."
    else:
      advice_1 = ""

    #Second and Third advice: 
    advice_2 = "Your sleep data shows that you have experienced a fairly good night."
    advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."

    if 'factor-awakenings' not in record: #Everything is positive.
      if 'no_disorders' in record: #Everything is positive.
        if 'action_for_good_sleep' in record:
          if 'factor-sleep_quality' in record: 
            if query == "Yes, it works" or query == "Cannot tell":
              advice_2 = "However, your sleep data shows that you have experienced a fairly good night."
              advice_3 = "My suggestion is to keep your current sleep hygiene practices and enjoy getting better sleep. You can take a look at this sleep report for more information." 
            elif query == "No, it doesn't":
              advice_2 = "However, your sleep data shows that you have experienced a fairly good night."
              advice_3 = "From this result, I think current practices are still useful. How about keeping for longer? You can take a look at this sleep report for more information."
          elif 'factor-sleep_quality' not in record:
            if query == "Yes, it works" or query == "Cannot tell":
              advice_2 = "Besides, your sleep data also shows a good night's sleep."
              advice_3 = "My suggestion is to keep your current sleep hygiene practices and enjoy getting better sleep. You can take a look at this sleep report for more information."
            elif query == "No, it doesn't":
              advice_2 = "Besides, your sleep data also shows a good night's sleep."
              advice_3 = "From this result, I think current practices are still useful. How about keeping for longer? You can take a look at this sleep report for more information."
        elif 'good_sleep_factor' in record:
          if 'factor-sleep_quality' in record:
            advice_2 = "However, your sleep data shows that you have experienced a fairly good night."
            advice_3 = "You have a good sleeping habit. To keep it, maybe you can take a look at this sleep report for further information."
          elif 'factor-sleep_quality' not in record:
            advice_2 = "Besides, your sleep data also shows a good night's sleep."
            advice_3 = "You have a good sleeping habit. To keep it, maybe you can take a look at this sleep report for further information."
        else:
          advice_2 = "Your sleep data shows that you have experienced a fairly good night."
          advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."
      else:
        advice_2 = "Your sleep data shows that you have experienced a fairly good night."
        advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."
    else:
      advice_2 = "Your sleep data shows that you have experienced a fairly good night."
      advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."

    factors = []
    scores = []
    final_factors = []
    final_scores = []
    main_factors = ""

    if "factor-awakenings" in record or "factor_primary-hard_sleep" in record or "factor_secondary-hard_sleep" in record or "inbed_routine" in record or "factor_primary-get_up_earlier" in record or "factor_secondary-get_up_earlier" in record or "factor_primary-sleep_not_enough" in record or "factor_secondary-sleep_not_enough" in record:
      if 'factor-awakenings' in record:
        factors.append(record['factor-awakenings'])
        scores.append(record['factor-awakenings-score'])
      else:
        factors.append('')
        scores.append('-1')
      if 'factor_primary-hard_sleep' in record:
        factors.append(record['factor_primary-hard_sleep'])
        scores.append(record['factor_primary-hard_sleep-score'])
      else:
        factors.append('')
        scores.append('-1')
      if 'factor_secondary-hard_sleep' in record:
        factors.append(record['factor_secondary-hard_sleep'])
        scores.append(record['factor_secondary-hard_sleep-score'])
      else:
        factors.append('')
        scores.append('-1')
      if "inbed_routine" in record:
        if "inbed_routine-score" in record:
          factors.append(record['inbed_routine'])
          scores.append(record['inbed_routine-score'])
        else:
          factors.append('')
          scores.append('-1')
      else:
        factors.append('')
        scores.append('-1')
      if 'factor_primary-get_up_earlier' in record:
        factors.append(record['factor_primary-get_up_earlier'])
        scores.append(record['factor_primary-get_up_earlier-score'])
      else:
        factors.append('')
        scores.append('-1')
      if 'factor_secondary-get_up_earlier' in record:
        factors.append(record['factor_secondary-get_up_earlier'])
        scores.append(record['factor_secondary-get_up_earlier-score'])
      else:
        factors.append('')
        scores.append('-1')
      if 'factor_primary-sleep_not_enough' in record:
        factors.append(record['factor_primary-sleep_not_enough'])
        scores.append(record['factor_primary-sleep_not_enough-score'])
      else:
        factors.append('')
        scores.append('-1')
      if 'factor_secondary-sleep_not_enough' in record:
        factors.append(record['factor_secondary-sleep_not_enough'])
        scores.append(record['factor_secondary-sleep_not_enough-score'])
      else:
        factors.append('')
        scores.append('-1')

      print(factors)
      print(scores)

      # final_factors = []
      # final_scores = []

      for i in range(0,8):
        repeat_time = 0
        score_list = []
        if factors[i] != "":
          score_list.append(int(scores[i]))
          print(i)
          for j in range(i,8):
            if i != j and factors[i] == factors[j]:
              repeat_time = repeat_time + 1
              score_list.append(int(scores[j]))
          if factors[i] not in final_factors:
            final_scores.append(max(score_list)+repeat_time)
            final_factors.append(factors[i])

      # print(final_factors)
      # print(final_scores)

      # main_factors = ""
      for i in range(0, len(final_factors)):
        if final_scores[i] >= 3:
          main_factors = main_factors + final_factors[i] + ", "
        if i == len(final_factors)-1:
          main_factors = main_factors[:-2]

      print(main_factors)

      if 'factor-sleep_quality' in record:
        if main_factors == "":
          advice_2 = "Besides, your sleep data confirms that your sleep tonight is a bit different from usual."
          advice_3 = "These sleep changes have not caused much impact. Here in your sleep report, I prepared several practices that you could try."
        elif main_factors != "":
          advice_2 = "Besides, your sleep data confirms that your sleep tonight is a bit different from usual."
          advice_3 = 'Factors like ' + main_factors.upper() + ' have a relatively big influence on your sleep quality. Maybe you can find some solutions here in your sleep report.'
        else:
          advice_2 = "Your sleep data shows that you have experienced a fairly good night."
          advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."
      elif 'factor-sleep_quality' not in record:
        if main_factors == "":
          advice_2 = "However, your sleep data shows that your sleep tonight is a bit different from usual."
          advice_3 = "These sleep changes have not caused much impact. Here in your sleep report, I prepared several practices that you could try."
        elif main_factors != "":
          advice_2 = "However, your sleep data shows that your sleep tonight is a bit different from usual."
          advice_3 = 'Factors like ' + main_factors.upper() + ' have a relatively big influence on your sleep quality. Maybe you can find some solutions here in your sleep report.'
        else:
          advice_2 = "Your sleep data shows that you have experienced a fairly good night."
          advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."
      else:
        advice_2 = "Your sleep data shows that you have experienced a fairly good night."
        advice_3 = "You have a good sleeping habit, please keep it. Besides, You can take a look at this sleep report for further information."

    final_actions = []
    final_action_scores = []
    web_address = "http://yliu.design/webReport/page2.html"
    if 'inbed_routine-positive-score' in record:
      final_actions.append(record['inbed_routine'])
      final_action_scores.append(int(record['inbed_routine-positive-score']))
    if 'action_works_score' in record:
      final_actions.append(record['action_for_good_sleep'])
      final_action_scores.append(int(record['action_works_score']))
    if 'good_sleep_factor' in record:
      final_actions.append(record['good_sleep_factor'])
      final_action_scores.append(3)


    print(final_actions)
    print(final_action_scores)

    if sender_id == "2941725442515722":
      web_address = "http://yliu.design/webReport/testaccount.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'yizhou_complete',
        'token': 'lyz95416'
      }
      # PARAMS = requests.get(url = URL, headers= HEADERS, json = {}).json()
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS) 

    elif sender_id == "2741133325984300":
      web_address = "http://yliu.design/webReport/testaccount.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'yizhou_complete',
        'token': 'lyz95416'
      }
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS) 

    elif sender_id == "3288915487803212":
      web_address = "http://yliu.design/webReport/pp1.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'yawei_complete',
        'token': 'lyz95416'
      }
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS) 

    elif sender_id == "2955503917870027":
      web_address = "http://yliu.design/webReport/pp2.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'xiaoyu_complete',
        'token': 'lyz95416'
      }
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS)

    elif sender_id == "3376883239008233":
      web_address = "http://yliu.design/webReport/pp3.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'sark_complete',
        'token': 'lyz95416'
      }
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS) 

    elif sender_id == "3781201318618542":
      web_address = "http://yliu.design/webReport/pp4.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'yunjie_complete',
        'token': 'lyz95416'
      }
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS) 

    elif sender_id == "3059608007493454":
      web_address = "http://yliu.design/webReport/pp5.html"
      HEADERS_COMPLETE = {
        'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
        'resource_id':'jingcai_complete',
        'token': 'lyz95416'
      }
      PARAMS = requests.get(url = URL, headers= HEADERS_COMPLETE, json = {}).json()

      if 'lasttime_factors' in PARAMS:
        PARAMS.update({'timebeforelasttime_factors': PARAMS['lasttime_factors']})
        PARAMS.update({'timebeforelasttime_scores': PARAMS['lasttime_scores']})
      if 'today_factors' in PARAMS:
        PARAMS.update({'lasttime_factors': PARAMS['today_factors']})
        PARAMS.update({'lasttime_scores': PARAMS['today_scores']})
      PARAMS.update({'today_factors': final_factors})
      PARAMS.update({'today_scores': final_scores})

      if 'lasttime_actions' in PARAMS:
        PARAMS.update({'timebeforelasttime_actions': PARAMS['lasttime_actions']})
        PARAMS.update({'timebeforelasttime_action_scores': PARAMS['lasttime_action_scores']})
      if 'today_actions' in PARAMS:
        PARAMS.update({'lasttime_actions': PARAMS['today_actions']})
        PARAMS.update({'lasttime_action_scores': PARAMS['today_action_scores']})
      PARAMS.update({'today_actions': final_actions})
      PARAMS.update({'today_action_scores': final_action_scores})

      total_factors = []
      total_scores = []
      total_timetags = []

      if 'timebeforelasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['timebeforelasttime_factors']
        total_scores = total_scores + PARAMS['timebeforelasttime_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_factors'])):
          total_timetags = total_timetags + ['day before yesterday']

      if 'lasttime_factors' in PARAMS:
        total_factors = total_factors + PARAMS['lasttime_factors']
        total_scores = total_scores + PARAMS['lasttime_scores']
        for i in range(0, len(PARAMS['lasttime_factors'])):
          total_timetags = total_timetags + ['yesterday']

      if 'today_factors' in PARAMS:
        total_factors = total_factors + PARAMS['today_factors']
        total_scores = total_scores + PARAMS['today_scores']
        for i in range(0, len(PARAMS['today_factors'])):
          total_timetags = total_timetags + ['today']

      total_actions = []
      total_action_scores = []
      total_action_timetags = []
      if 'timebeforelasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['timebeforelasttime_actions']
        total_action_scores = total_action_scores + PARAMS['timebeforelasttime_action_scores']
        for i in range(0, len(PARAMS['timebeforelasttime_actions'])):
          total_action_timetags = total_action_timetags + ['day before yesterday']

      if 'lasttime_actions' in PARAMS:
        total_actions = total_actions + PARAMS['lasttime_actions']
        total_action_scores = total_action_scores + PARAMS['lasttime_action_scores']
        for i in range(0, len(PARAMS['lasttime_actions'])):
          total_action_timetags = total_action_timetags + ['yesterday']

      if 'today_actions' in PARAMS:
        total_actions = total_actions + PARAMS['today_actions']
        total_action_scores = total_action_scores + PARAMS['today_action_scores']
        for i in range(0, len(PARAMS['today_actions'])):
          total_action_timetags = total_action_timetags + ['today']

      P_extra = {'total_factors': total_factors, 'total_scores': total_scores, "total_timetags": total_timetags, 'total_actions': total_actions, 'total_action_scores': total_action_scores, 'total_action_timetags': total_action_timetags}
      print(P_extra)
      PARAMS.update(P_extra)

      r_put = requests.post(url = URL, headers= HEADERS_COMPLETE, json = PARAMS) 

    reply = {
      "followupEventInput": {
        "name": "sleep-report-4-1",
        "languageCode": "en-US",
        "parameters":{
          "advice_0": advice_0,
          "advice_1": advice_1,
          "advice_2": advice_2,
          "advice_3": advice_3,
          "web_address": web_address,
        }
      }
    }
    stepdf.at[0, sender_id] = '1-1'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

  if dialog_step == '5-1':
    reply = {
      "followupEventInput": {
        "name": "pause-chat-5-1",
        "languageCode": "en-US",
      }
    }
    stepdf.at[0, sender_id] = '1-1'
    stepdf.to_csv('step.csv', columns=['2941725442515722', '2741133325984300', '3288915487803212', '2955503917870027', '3376883239008233', '3781201318618542','3059608007493454'], header=True, index=False)

  # if dialog_step == '1.2':
  #   duration_hour = int(sleep_sum_A['duration']/3600000)
  #   duration_minute = int((sleep_sum_A['duration']%3600000)/60000)
  #   starttime_hour = sleep_sum_A['startTime'].split('T')[1].split(':')[0]
  #   starttime_minute = sleep_sum_A['startTime'].split('T')[1].split(':')[1]

  return jsonify(reply)



