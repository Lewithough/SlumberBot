'''
  speech.py - Contains functions to construct speech from data variables

  Written by Nicholas Cannon
'''
import random

def sleep_speech(sp_data):
  '''
  Constructs sleep statistics speech.
  sp_data = sleep data dictionary returned from get_sleep_data function.
  '''
  responses = [
    f"Last night you got {sp_data['time asleep']['hours']} hours and {sp_data['time asleep']['minutes']} minutes of sleep. You fell asleep at {sp_data['bedtime']['hours']}:{sp_data['bedtime']['minutes']}. Did you want to here your sleep stages?",
    f"Last night you fell asleep at {sp_data['bedtime']['hours']}:{sp_data['bedtime']['minutes']} and managed to get {sp_data['time asleep']['hours']} hours and {sp_data['time asleep']['minutes']} minutes of sleep. Did you want to know how many minutes you spent in each stage?",
    f"You managed to fall asleep at {sp_data['bedtime']['hours']}:{sp_data['bedtime']['minutes']} and get {sp_data['time asleep']['hours']} hours and {sp_data['time asleep']['minutes']} minutes of sleep. Did you also want to hear how long you spent in each stage of sleep?"
  ]

  return responses[random.randrange(0, len(responses))]

def stage_speech(stages):
  '''
  Constructs stage stats speech.
  '''
  responses = [
    f"Ok, you spent {stages['deep']} minutes in deep sleep, {stages['rem']} minutes in rem sleep, {stages['light']} minutes in light sleep and {stages['wake']} minutes awake.",
    f"Alright, you got {stages['deep']} minutes in deep sleep, {stages['rem']} minutes in rem sleep, {stages['light']} minutes in light sleep and {stages['wake']} minutes awake.",
    f"No worries, you managed to get {stages['deep']} minutes in deep sleep, {stages['rem']} minutes in rem sleep, {stages['light']} minutes in light sleep and {stages['wake']} minutes awake."
  ]
  return responses[random.randrange(0, len(responses))]