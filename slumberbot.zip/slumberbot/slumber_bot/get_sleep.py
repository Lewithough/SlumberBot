'''
  get_sleep.py - Gets sleep data from Fitbit WEB API
  WEB API DOCS: https://dev.fitbit.com/build/reference/web-api/

  Written by Nicholas Cannon
'''
from flask import current_app
import fitbit, datetime, requests, base64, json, os
from cryptography.fernet import Fernet
from simplekv.fs import FilesystemStore

def decrypt_token(token):
  '''Decryptes token'''
  f = Fernet(current_app.config['CRYPT_SECRET'])
  return f.decrypt(token).decode()

def encrypt_token(token):
  '''Encrypts a new token'''
  f = Fernet(current_app.config['CRYPT_SECRET'])
  return f.encrypt(token.encode())

def refresh_api_token(old_refresh_token):
  '''
  Refreshes API token and pickles a new token values.
  Details: https://dev.fitbit.com/build/reference/web-api/oauth2/#refreshing-tokens
  '''
  url = 'https://api.fitbit.com/oauth2/token'
  bytes_code = current_app.config['CONSUMER_KEY']+':'+current_app.config['FITBIT_SECRET'] #获取code #从config.py中读取
  auth_codeCRYPT_SECRET = base64.b64encode(bytes_code.encode()).decode('utf8') #处理code
  headers = {
    'Authorization': 'Basic ' + auth_code,
    'content-type':'application/x-www-form-urlencoded'
  }
  data = {
    'grant_type': 'refresh_token',
    'refresh_token': old_refresh_token,
    'expires_in': 28800
  }
  r = requests.post(url, headers=headers, data=data)

  if r.status_code != 200:
    print(r.content)
    raise TokenRefreshError()

  tokens = json.loads(r.content)

  # pickle encrypted tokens
  db = FilesystemStore(current_app.config['STORE_PATH'])
  db.put('refresh_token', encrypt_token(tokens['refresh_token']))
  db.put('access_token', encrypt_token(tokens['access_token']))

  return tokens['access_token'], tokens['refresh_token']
  
def get_sleep_data(access_token, refresh_token, date):
  '''
  Returns Dictionary with Fitbit sleep data for the date specified.
  date=datetime object with date of desired sleep data

  Raises FitbitSyncError if sleep data not synced with fitbit app.
  '''
  client = fitbit.Fitbit(
    current_app.config['CONSUMER_KEY'], current_app.config['FITBIT_SECRET'], 
    access_token=access_token, refresh_token=refresh_token, 
    oauth2=True)

  sleep_data = client.sleep(date=date)
  try: # 此处可根据Fitbit实际读取到的内容添加各类数据
    stage_data = sleep_data['summary']['stages']
    # Parse datetime string, example strng is '2019-03-17T08:51:30.000'
    starttime = datetime.datetime.strptime(
      sleep_data['sleep'][0]['startTime'][:-3], '%Y-%m-%dT%H:%M:%S.')
    awakes = sleep_data['sleep'][0][awakeCount]
  except KeyError:
    # sleep_data won't contain a stages key if the fitbit hasn't been sync'd
    raise FitbitSyncError()

  # Process returned data
  data = {
    'time asleep': {
      'hours': (stage_data['deep']+stage_data['rem']+stage_data['light'])//60,
      'minutes': (stage_data['deep']+stage_data['rem']+stage_data['light'])%60
    },
    'stages': stage_data,
    'total time': {
      'hours': (stage_data['deep']+stage_data['rem']+stage_data['light']+stage_data['wake'])//60,
      'minutes': (stage_data['deep']+stage_data['rem']+stage_data['light']+stage_data['wake'])%60
    },
    'bedtime': {
      'hours': bedtime.hour%12, # 24 hour format
      'minutes': bedtime.minute
    },
    'awakes': awakes,
  }

  return data

'''Custom Exceptions'''
class FitbitSyncError(Exception):
  def __init__(self, *args, **kwargs):
    Exception.__init__(self, *args, **kwargs)

class TokenRefreshError(Exception):
  def __init__(self, *args, **kwargs):
    Exception.__init__(self, *args, **kwargs)