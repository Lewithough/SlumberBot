from flask import Flask, request, jsonify, render_template, current_app
import datetime, base64, os, requests, json, random, cherrypy, csv
import gather_keys_oauth2 as Oauth2 
import fitbit

def get_sleep_TEST(date):
  CLIENT_ID = '22B9KR'
  CLIENT_SECRET = '61e4679e4d2bf728b855a3e3b220f449'

  server = Oauth2.OAuth2Server(CLIENT_ID, CLIENT_SECRET)
  server.browser_authorize()
  ACCESS_TOKEN = str(server.fitbit.client.session.token['access_token'])
  REFRESH_TOKEN = str(server.fitbit.client.session.token['refresh_token'])
  auth2_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, oauth2=True, access_token=ACCESS_TOKEN, refresh_token=REFRESH_TOKEN)

  """Sleep log"""
  fit_statsSl = auth2_client.sleep(date)
  """Sleep Summary"""
  fit_statsSum = auth2_client.sleep(date)['sleep'][0]

  return fit_statsSl, fit_statsSum

def get_sleep_A(date):
  CLIENT_ID = '22BPXR'
  CLIENT_SECRET = '8f2c9f3f46832bcfe7fedbec987de9fb'
  print('pp1-A')

  server = Oauth2.OAuth2Server(CLIENT_ID, CLIENT_SECRET)
  server.browser_authorize()
  ACCESS_TOKEN = str(server.fitbit.client.session.token['access_token'])
  REFRESH_TOKEN = str(server.fitbit.client.session.token['refresh_token'])
  auth2_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, oauth2=True, access_token=ACCESS_TOKEN, refresh_token=REFRESH_TOKEN)

  """Sleep log"""
  fit_statsSl = auth2_client.sleep(date)
  """Sleep Summary"""
  fit_statsSum = auth2_client.sleep(date)['sleep'][0]

  return fit_statsSl, fit_statsSum

def get_sleep_B(date):
  CLIENT_ID = '22BR6S'
  CLIENT_SECRET = 'c94e81beb83002b8467cd1750a3e8d96'
  print('pp2-B')

  server = Oauth2.OAuth2Server(CLIENT_ID, CLIENT_SECRET)
  server.browser_authorize()
  ACCESS_TOKEN = str(server.fitbit.client.session.token['access_token'])
  REFRESH_TOKEN = str(server.fitbit.client.session.token['refresh_token'])
  auth2_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, oauth2=True, access_token=ACCESS_TOKEN, refresh_token=REFRESH_TOKEN)

  """Sleep log"""
  fit_statsSl = auth2_client.sleep(date)

  """Sleep Summary"""
  fit_statsSum = auth2_client.sleep(date)['sleep'][0]

  return fit_statsSl, fit_statsSum

def get_sleep_C(date):
  CLIENT_ID = '22BR6Q'
  CLIENT_SECRET = 'cc3b9a19a619f54778d6e02f9bbe8765'
  print('pp3-C')

  server = Oauth2.OAuth2Server(CLIENT_ID, CLIENT_SECRET)
  server.browser_authorize()
  ACCESS_TOKEN = str(server.fitbit.client.session.token['access_token'])
  REFRESH_TOKEN = str(server.fitbit.client.session.token['refresh_token'])
  auth2_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, oauth2=True, access_token=ACCESS_TOKEN, refresh_token=REFRESH_TOKEN)

  """Sleep log"""
  fit_statsSl = auth2_client.sleep(date)

  """Sleep Summary"""
  fit_statsSum = auth2_client.sleep(date)['sleep'][0]

  return fit_statsSl, fit_statsSum

def get_sleep_D(date):
  CLIENT_ID = '22BR6P'
  CLIENT_SECRET = '06f640f923a93cd0fcd86d9dc7dc68a4'
  print('pp4-D')

  server = Oauth2.OAuth2Server(CLIENT_ID, CLIENT_SECRET)
  server.browser_authorize()
  ACCESS_TOKEN = str(server.fitbit.client.session.token['access_token'])
  REFRESH_TOKEN = str(server.fitbit.client.session.token['refresh_token'])
  auth2_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, oauth2=True, access_token=ACCESS_TOKEN, refresh_token=REFRESH_TOKEN)

  """Sleep log"""
  fit_statsSl = auth2_client.sleep(date)

  """Sleep Summary"""
  fit_statsSum = auth2_client.sleep(date)['sleep'][0]

  return fit_statsSl, fit_statsSum

def get_sleep_E(date):
  CLIENT_ID = '22BR5S'
  CLIENT_SECRET = '66ae9b1807a653bc89e0b934927c6b0c'
  print('pp5-E')

  server = Oauth2.OAuth2Server(CLIENT_ID, CLIENT_SECRET)
  server.browser_authorize()
  ACCESS_TOKEN = str(server.fitbit.client.session.token['access_token'])
  REFRESH_TOKEN = str(server.fitbit.client.session.token['refresh_token'])
  auth2_client = fitbit.Fitbit(CLIENT_ID, CLIENT_SECRET, oauth2=True, access_token=ACCESS_TOKEN, refresh_token=REFRESH_TOKEN)

  """Sleep log"""
  fit_statsSl = auth2_client.sleep(date)

  """Sleep Summary"""
  fit_statsSum = auth2_client.sleep(date)['sleep'][0]

  return fit_statsSl, fit_statsSum