'''
  config.test.py - Test Flask configuration file. Replace values with actual
  project values.

  Written by Nicholas Cannon
'''
import os

BASE_DIR = os.getcwd()
SECRET = ''
CRYPT_SECRET = b''  # Secret for encrypting tokens dict

STORE_PATH = os.path.join(BASE_DIR, 'fitbit_bot', 'site')

PROJECT_ID = 'newagent-wdttck' # google project id

# Fitbit values
CONSUMER_KEY = '22B9KR'  # CLIENT_ID
FITBIT_SECRET = '61e4679e4d2bf728b855a3e3b220f449' # CLIENT_SECRET