// var json = '{"total_factors" : ["Stress and Anxiety", "Noise", "Temperature", "Pet", "Noise", "Nightmare"], "total_scores" : ["2", "1", "1", "1", "4","1"], "factors" : ["Stress", "Noise", "Temperature"], "sleepDuration":"8 hours", "sleepTime": "23:20 to 7:25", "sleepAwake": "2 times", "actions" : ["Sleep early", "Ban the phone", "Stretch for sleep", "Play less video games"]}'
var obj = '';

$.ajax(
  {
    url: 'https://data.id.tue.nl/datasets/entity/249/item/',
    headers: {
      'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
      'resource_id': 'yizhou_complete',
      'token': 'lyz95416'
    },
    type: 'GET',
    async:false,
    contentType: 'application/json',
    success: function(data) {
      console.log(data)
      obj = data
    },
    error: function(e) {
      console.log(e)
    }
  }
);

var factor_stress = ["<b>Exercise.</b> Regular exercise is good for your physical and mental health. It provides an outlet for frustrations and releases mood-enhancing endorphins. Yoga can be particularly effective at reducing anxiety and stress.","<b>Prioritize your to-do list.</b> Spend your time and energy on the tasks that are truly important, and break up large projects into smaller, more easily managed tasks. Delegate when you can.", "<b>Play music.</b> Soft, calming music can lower your blood pressure and relax your mind and body.", "<b>Get an adequate amount of sleep.</b> Sleeping recharges your brain and improves your focus, concentration, and mood."]
var factor_nightmare = ["<b>Keeping a regular wake-sleep schedule.</b> Maintaining the timing of the body's internal clock and can help you fall asleep and wake up more easily.","<b>Exercise.</b> Regular exercise can help alleviate nightmare-causing anxiety and stress. You may find that yoga and meditation are also helpful.", "<b>Practice good sleep hygiene.</b> Make your bedroom a relaxing, tranquil place that is reserved for sleep, so that you don't associate it with stressful activities.", "<b>Be cautious about the use of alcohol, caffeine, and nicotine</b>, which can remain in your system for more than 12 hours and often disrupt sleep patterns."]
var factor_noise = ["<b>Keeping windows closed</b> also will limit noise from outside.","<b>White noise</b> can help to block variable noises and provides constant, soothing sounds that can help you fall asleep and stay asleep throughout the night.", "<b>Play familiar sounds that come from nature</b>, such as breaking waves, crickets softly chirping, or wind rustling through leaves.", "<b>Earplugs</b> can help when you can't completely control the sounds around you."]
var factor_urination = ["<b>Limit your intake of fluids two hours before bedtime.</b>"]
var factor_indigestion = ["<b>Waiting for three to four hours after you eat before going to bed.</b> That gives your stomach a chance to process your meal and move it through your digestive system.", "<b>Eating a smaller and lighter dinner also is a good idea.</b> Your stomach will then be empty and less likely to promote reflux when you lie down."]
var factor_nightsweat = ["<b>Give some treatment on your infections.</b> Many infections can cause a fever, which in turn leads to night sweats.", "<b>Adjust your medication.</b> Certain medications, such as antidepressants, are known to be associated with night sweats. You should talk to your doctor about that."]
var factor_light = ["<b>Turn off all the lights and screens</b> that under your control. If you must leave a night light, choose the red or orange ones.", "<b>Put up light-blocking shades or curtains</b> to keep ambient light, such as your neighbor’s porch light, out of your room.", "<b>Try wearing a sleep mask over your eyes</b>, if there is no other choices."]
var factor_cold = ["<b>Keep ambient temperatures between 20-23 degrees.</b>", "<b>Keep hands and feet warm with socks or a warm water bottle.</b>", "<b>Take a warm bath 1-2 hours before bed.</b> The drop in temperature as you get out of the tub can help your body prepare for sleep."]
var factor_hot = ["<b>Keep ambient temperatures between 20-23 degrees.</b>", "<b>Avoid exercising close to bed time</b>, as it will increase your internal temperature.", "<b>Remove excess clothing and winter bedding.</b>", "Leave an open window so fresh air can flow through the room."]
var factor_electronics = ["<b>Try to turn off all the screens 30 minutes before your sleep.</b>", "<b>Try to find a substitution to using electronics.</b> One good choice is reading."]
var factor_discomfort = ["<b>Gentle massage, deep breathing, and relaxation techniques</b> are all generally considered beneficial with respect to chronic pain management."]
var factor_caffeine = ["<b>Avoid caffeine close to bedtime</b>, and try not intake too much caffeine in 6 hours before sleep."]
var factor_alcohol = ["<b>Avoid Alcohol close to bedtime.</b>"]
var factor_schedule = ["<b>Consider a Nap in daytime.</b> A short nap in daytime can help you to recharge and balance the loss of last night.","<b>Try to change your timetable to fit your regular sleep-wake cycle.</b>"]
var factor_sleepearly = ["<b>Gradually shift your bedtime later</b>, in 15 or 30-minute increments, until you’re waking at the time that’s right for you."]
var factor_workandstudy = ["<b>Remember not everything is as urgent as it feels.</b> The truth is, a lot of those emails can wait until tomorrow, while a good night's sleep cannot.","<b>Consider a Nap.</b> A short nap in daytime can help you to recharge.  Keep yours to about 20 minutes, which is the sweet spot when it comes to napping.","<b>Make Time for Mindfulness.</b> A few minutes of meditation or slow breathing can help reduce any work stress you're experiencing.","<b>Try to keep a regular sleep-wake cycle.</b>"]
var factor_entertainment = ["<b>Plan your evening every day.</b> Whether you are caught up with chores or have free time to spend, having a plan will help ensure you go to bed on top."]

window.onload=function(){
    var dyn = document.getElementById('word-cloud');
    var len_n = obj.total_factors.length;
    var len_p = obj.total_actions.length;
    console.log(len_n);
    console.log(len_p);
    
    if(len_n > 0){
        console.log('hes');
        var wcnegative = document.createElement("div");
        wcnegative.setAttribute("id","word-cloud-negative");
        wcnegative.setAttribute("class","word-cloud-negative");
        dyn.appendChild(wcnegative);

        var blank = document.createElement("div");
        blank.setAttribute("class","blank");
        dyn.appendChild(blank);

        var float = document.createElement("div");
        float.setAttribute("class","float");
        dyn.appendChild(float);

        anychart.onDocumentReady(function(){
            var len = obj.total_factors.length;
            console.log(len);

            var dataarray = new Array();

            for (var i = 0; i < len; i++){
                dataarray[i] = {"x": obj.total_factors[i], "value": obj.total_scores[i], category: obj.total_timetags[i]};
            }

            // create a tag (word) cloud chart
            var chart = anychart.tagCloud(dataarray);

            // set a chart title
            chart.title('Negative factors in three days')
            // set an array of angles at which the words will be laid out
            chart.angles([0])
            // enable a color range
            chart.colorRange(true);
            // set the color range length
            chart.colorRange().length('80%');

            // display the word HEADERcloud chart
            chart.container("word-cloud-negative");
            chart.draw();
        });
    }

    if(len_p > 0){
        var wcpositive = document.createElement("div");
        wcpositive.setAttribute("id","word-cloud-positive");
        wcpositive.setAttribute("class","word-cloud-positive");
        dyn.appendChild(wcpositive);

        var blank2 = document.createElement("div");
        blank2.setAttribute("class","blank");
        dyn.appendChild(blank2);

        var float2 = document.createElement("div");
        float2.setAttribute("class","float2");
        dyn.appendChild(float2);

        anychart.onDocumentReady(function(){
            var len = obj.total_actions.length;
            console.log(len);

            var dataarray = new Array();

            for (var i = 0; i < len; i++){
                dataarray[i] = {"x": obj.total_actions[i], "value": obj.total_action_scores[i], category: obj.total_action_timetags[i]};
            }
            
            // create a tag (word) cloud chart
            var chart = anychart.tagCloud(dataarray);

            // set a chart title
            chart.title('Positive factors in three days')
            // set an array of angles at which the words will be laid out
            chart.angles([0])
            // enable a color range
            chart.colorRange(true);
            // // set the color range length
            chart.colorRange().length('80%');

            // display the word cloud chart
            chart.container("word-cloud-positive");
            chart.draw(); 
        });
    }

    var dyn2 = document.getElementById('dynamic-factors'); 
    for(var i = 0; i < obj.today_factors.length; i ++){
        if(!document.getElementById('factor'+i))
        {
            var f_title = document.createElement("div");
            f_title.setAttribute("id","factor"+i);
            f_title.setAttribute("class","factor-title");
            f_title.innerHTML=obj.today_factors[i];
            dyn2.appendChild(f_title);

            if(obj.today_factors[i] == "Stress and anxiety"){
                for(var j = 0; j < factor_stress.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_stress[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Nightmare"){
                for(var j = 0; j < factor_nightmare.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_nightmare[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Noise"){
                for(var j = 0; j < factor_noise.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_noise[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Urination"){
                for(var j = 0; j < factor_urination.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_urination[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Indigestion"){
                for(var j = 0; j < factor_indigestion.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_indigestion[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Night sweat"){
                for(var j = 0; j < factor_nightsweat.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_nightsweat[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Light"){
                for(var j = 0; j < factor_light.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_light[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Cold temperature"){
                for(var j = 0; j < factor_cold.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_cold[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Hot temperature"){
                for(var j = 0; j < factor_hot.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_hot[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Using electronics"){
                for(var j = 0; j < factor_electronics.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_electronics[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Discomfort"){
                for(var j = 0; j < factor_discomfort.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_discomfort[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Caffeine"){
                for(var j = 0; j < factor_caffeine.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_caffeine[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Alcohol"){
                for(var j = 0; j < factor_alcohol.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_alcohol[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Working schedule"){
                for(var j = 0; j < factor_schedule.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_schedule[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Earlier slept"){
                for(var j = 0; j < factor_sleepearly.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_sleepearly[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Work and study"){
                for(var j = 0; j < factor_workandstudy.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_workandstudy[j];
                    dyn2.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Entertainment"){
                for(var j = 0; j < factor_entertainment.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_entertainment[j];
                    dyn2.appendChild(f_tips);
                }
            }
        }
    }
}


