
var obj = '';

$.ajax(
  {
    url: 'https://data.id.tue.nl/datasets/entity/249/item/',
    headers: {
      'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
      'resource_id': 'yizhou_complete',
      'token': 'lyz95416'
    },
    type: 'GET',
    async:false,
    contentType: 'application/json',
    success: function(data) {
      console.log(data)
      obj = data
    },
    error: function(e) {
      console.log(e)
    }
  }
);

var factor_stress = ["<b>Exercise.</b> Regular exercise is good for your physical and mental health. It provides an outlet for frustrations and releases mood-enhancing endorphins. Yoga can be particularly effective at reducing anxiety and stress.","<b>Prioritize your to-do list.</b> Spend your time and energy on the tasks that are truly important, and break up large projects into smaller, more easily managed tasks. Delegate when you can.", "<b>Play music.</b> Soft, calming music can lower your blood pressure and relax your mind and body.", "<b>Get an adequate amount of sleep.</b> Sleeping recharges your brain and improves your focus, concentration, and mood."]
var factor_nightmare = ["<b>Keeping a regular wake-sleep schedule.</b> Maintaining the timing of the body's internal clock and can help you fall asleep and wake up more easily.","<b>Exercise.</b> Regular exercise can help alleviate nightmare-causing anxiety and stress. You may find that yoga and meditation are also helpful.", "<b>Practice good sleep hygiene.</b> Make your bedroom a relaxing, tranquil place that is reserved for sleep, so that you don't associate it with stressful activities.", "<b>Be cautious about the use of alcohol, caffeine, and nicotine</b>, which can remain in your system for more than 12 hours and often disrupt sleep patterns."]
var factor_noise = ["<b>Keeping windows closed</b> also will limit noise from outside.","<b>White noise</b> can help to block variable noises and provides constant, soothing sounds that can help you fall asleep and stay asleep throughout the night.", "<b>Play familiar sounds that come from nature</b>, such as breaking waves, crickets softly chirping, or wind rustling through leaves.", "<b>Earplugs</b> can help when you can't completely control the sounds around you."]
var factor_urination = ["<b>Limit your intake of fluids two hours before bedtime.</b>"]
var factor_indigestion = ["<b>Waiting for three to four hours after you eat before going to bed.</b> That gives your stomach a chance to process your meal and move it through your digestive system.", "<b>Eating a smaller and lighter dinner also is a good idea.</b> Your stomach will then be empty and less likely to promote reflux when you lie down."]
var factor_nightsweat = ["<b>Give some treatment on your infections.</b> Many infections can cause a fever, which in turn leads to night sweats.", "<b>Adjust your medication.</b> Certain medications, such as antidepressants, are known to be associated with night sweats. You should talk to your doctor about that."]
var factor_light = ["<b>Turn off all the lights and screens</b> that under your control. If you must leave a night light, choose the red or orange ones.", "<b>Put up light-blocking shades or curtains</b> to keep ambient light, such as your neighbor’s porch light, out of your room.", "<b>Try wearing a sleep mask over your eyes</b>, if there is no other choices."]
var factor_cold = ["<b>Keep ambient temperatures between 20-23 degrees.</b>", "<b>Keep hands and feet warm with socks or a warm water bottle.</b>", "<b>Take a warm bath 1-2 hours before bed.</b> The drop in temperature as you get out of the tub can help your body prepare for sleep."]
var factor_hot = ["<b>Keep ambient temperatures between 20-23 degrees.</b>", "<b>Avoid exercising close to bed time</b>, as it will increase your internal temperature.", "<b>Remove excess clothing and winter bedding.</b>", "Leave an open window so fresh air can flow through the room."]
var factor_electronics = ["<b>Try to turn off all the screens 30 minutes before your sleep.</b>", "<b>Try to find a substitution to using electronics.</b> One good choice is reading."]
var factor_discomfort = ["<b>Gentle massage, deep breathing, and relaxation techniques</b> are all generally considered beneficial with respect to chronic pain management."]
var factor_caffeine = ["<b>Avoid caffeine close to bedtime</b>, and try not intake too much caffeine in 6 hours before sleep."]
var factor_alcohol = ["<b>Avoid Alcohol close to bedtime.</b>"]
var factor_schedule = ["<b>Consider a Nap in daytime.</b> A short nap in daytime can help you to recharge and balance the loss of last night.","<b>Try to change your timetable to fit your regular sleep-wake cycle.</b>"]
var factor_sleepearly = ["<b>Gradually shift your bedtime later</b>, in 15 or 30-minute increments, until you’re waking at the time that’s right for you."]
var factor_workandstudy = ["<b>Remember not everything is as urgent as it feels.</b> The truth is, a lot of those emails can wait until tomorrow, while a good night's sleep cannot.","<b>Consider a Nap.</b> A short nap in daytime can help you to recharge.  Keep yours to about 20 minutes, which is the sweet spot when it comes to napping.","<b>Make Time for Mindfulness.</b> A few minutes of meditation or slow breathing can help reduce any work stress you're experiencing.","<b>Try to keep a regular sleep-wake cycle.</b>"]
var factor_entertainment = ["<b>Plan your evening every day.</b> Whether you are caught up with chores or have free time to spend, having a plan will help ensure you go to bed on top."]

window.onload=function(){
    var dyn = document.getElementById('dynamic-factors'); 

    for(var i = 0; i < obj.today_factors.length; i ++){
        if(!document.getElementById('factor'+i))
        {
            var f_title = document.createElement("div");
            f_title.setAttribute("id","factor"+i);
            f_title.setAttribute("class","factor-title");
            f_title.innerHTML=obj.today_factors[i];
            dyn.appendChild(f_title);

            if(obj.today_factors[i] == "Stress and anxiety"){
                for(var j = 0; j < factor_stress.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_stress[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Nightmare"){
                for(var j = 0; j < factor_nightmare.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_nightmare[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Noise"){
                for(var j = 0; j < factor_noise.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_noise[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Urination"){
                for(var j = 0; j < factor_urination.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_urination[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Indigestion"){
                for(var j = 0; j < factor_indigestion.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_indigestion[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Night sweat"){
                for(var j = 0; j < factor_nightsweat.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_nightsweat[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Light"){
                for(var j = 0; j < factor_light.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_light[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Cold temperature"){
                for(var j = 0; j < factor_cold.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_cold[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Hot temperature"){
                for(var j = 0; j < factor_hot.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_hot[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Using electronics"){
                for(var j = 0; j < factor_electronics.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_electronics[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Discomfort"){
                for(var j = 0; j < factor_discomfort.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_discomfort[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Caffeine"){
                for(var j = 0; j < factor_caffeine.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_caffeine[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Alcohol"){
                for(var j = 0; j < factor_alcohol.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_alcohol[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Working schedule"){
                for(var j = 0; j < factor_schedule.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_schedule[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Earlier slept"){
                for(var j = 0; j < factor_sleepearly.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_sleepearly[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Work and study"){
                for(var j = 0; j < factor_workandstudy.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_workandstudy[j];
                    dyn.appendChild(f_tips);
                }
            }else if(obj.today_factors[i] == "Entertainment"){
                for(var j = 0; j < factor_entertainment.length; j ++){
                    var f_tips = document.createElement("div");
                    f_tips.setAttribute("class","factor-tips");
                    f_tips.innerHTML = factor_entertainment[j];
                    dyn.appendChild(f_tips);
                }
            }
        }
    }
} 
    // var sleepData = new Array();
    // sleepData[0] = "Sleep Duration";
    // sleepData[1] = "Sleep Time";
    // sleepData[2] = "Awakenings";

    // var title1 = document.createElement("div");
    // title1.setAttribute("class","chapter-title");
    // title1.innerHTML="Sleep Factors";
    // dyn.appendChild(title1);

    // var subtitle1 = document.createElement("div");
    // subtitle1.setAttribute("class","chapter-subtitle");
    // subtitle1.innerHTML="Which factors have the most impact on your sleep?";
    // dyn.appendChild(subtitle1);

    // var i = 0;
    // while(i < obj.total_factors.length)
    // {
    //     if(!document.getElementById('factor'+i))
    //     {
    //         var ele = document.createElement("div");
    //         ele.setAttribute("id","factor"+i);
    //         ele.setAttribute("class","factor_graph");
    //         ele.setAttribute("class","factors");
    //         ele.innerHTML=obj.total_factors[i];
    //         dyn.appendChild(ele);


    //     }
    //     i++;
    // }

    // var i=0;
    // while(i<obj.factors.length)
    // {
    //     if(!document.getElementById('timedrpact'+i))
    //     {
    //         var ele = document.createElement("div");
    //         var url = obj.factors[i] + '.html';
    //         console.log(url);
    //         ele.setAttribute("id","timedrpact"+i);
    //         ele.setAttribute("class","factors");
    //         ele.setAttribute("onclick","window.location.href='"+url+"'");
    //         ele.innerHTML=obj.factors[i];
    //         dyn.appendChild(ele);
    //     }
    //     i++;
    // }

//     var clear1 = document.createElement("div");
//     clear1.setAttribute("class","clear");
//     dyn.appendChild(clear1);

//     var title3 = document.createElement("div");
//     title3.setAttribute("class","chapter-title");
//     title3.innerHTML="Actions";
//     dyn.appendChild(title3);

//     var i=0;
//     while(i<obj.actions.length)
//     {
//         if(!document.getElementById('timedrpact3'+i))
//         {
//             var ele3 = document.createElement("div");
//             // var url = obj.actions[i] + '.html';
//             // console.log(url);
//             ele3.setAttribute("id","timedrpact3"+i);
//             ele3.setAttribute("class","actions");
//             // ele.setAttribute("onclick","window.location.href='"+url+"'");
//             ele3.innerHTML=obj.actions[i];
//             dyn.appendChild(ele3);
//         }
//         i++;
//     }

//     var clear1 = document.createElement("div");
//     clear1.setAttribute("class","clear");
//     dyn.appendChild(clear1);

//     var title2 = document.createElement("div");
//     title2.setAttribute("class","chapter-title");
//     title2.innerHTML="Sleep Data";
//     dyn.appendChild(title2);

//     var i=0;
//     while(i<3)
//     {
//         if(!document.getElementById('timedrpact2'+i))
//         {
//             var subtitle = document.createElement("div");
//             subtitle.setAttribute("id","subtitle");
//             subtitle.setAttribute("class","subtitle");
//             subtitle.innerHTML=sleepData[i];
//             dyn.appendChild(subtitle);
            
//             // var clear2 = document.createElement("div");
//             // clear2.setAttribute("class","clear-2");
//             // subtitle.appendChild(clear2);

//             var ele2 = document.createElement("div");
//             ele2.setAttribute("id","timedrpact2"+i);
//             ele2.setAttribute("class","sleepData");
//             ele2.innerHTML=objArray[i];
//             subtitle.appendChild(ele2);

//             // var modify = document.createElement("div");
//             // modify.setAttribute("id","modify"+i);
//             // modify.setAttribute("class","modification");
//             // modify.innerHTML="modify";
//             // subtitle.appendChild(modify);
//         }
//         i++;
//     }
// };

// window.onload=function(){
//     var dyn = document.getElementById('dynamic-factors'); 
//     var obj = JSON.parse(json);

//     var objArray = new Array();
//     objArray[0] = obj.sleepDuration;
//     objArray[1] = obj.sleepTime;
//     objArray[2] = obj.sleepAwake;

//     var sleepData = new Array();
//     sleepData[0] = "Sleep Duration";
//     sleepData[1] = "Sleep Time";
//     sleepData[2] = "Awakenings";

//     var title1 = document.createElement("div");
//     title1.setAttribute("class","chapter-title");
//     title1.innerHTML="Factors";
//     dyn.appendChild(title1);

//     var i=0;
//     while(i<obj.factors.length)
//     {
//         if(!document.getElementById('timedrpact'+i))
//         {
//             var ele = document.createElement("div");
//             var url = obj.factors[i] + '.html';
//             console.log(url);
//             ele.setAttribute("id","timedrpact"+i);
//             ele.setAttribute("class","factors");
//             ele.setAttribute("onclick","window.location.href='"+url+"'");
//             ele.innerHTML=obj.factors[i];
//             dyn.appendChild(ele);
//         }
//         i++;
//     }

//     var clear1 = document.createElement("div");
//     clear1.setAttribute("class","clear");
//     dyn.appendChild(clear1);

//     var title3 = document.createElement("div");
//     title3.setAttribute("class","chapter-title");
//     title3.innerHTML="Actions";
//     dyn.appendChild(title3);

//     var i=0;
//     while(i<obj.actions.length)
//     {
//         if(!document.getElementById('timedrpact3'+i))
//         {
//             var ele3 = document.createElement("div");
//             // var url = obj.actions[i] + '.html';
//             // console.log(url);
//             ele3.setAttribute("id","timedrpact3"+i);
//             ele3.setAttribute("class","actions");
//             // ele.setAttribute("onclick","window.location.href='"+url+"'");
//             ele3.innerHTML=obj.actions[i];
//             dyn.appendChild(ele3);
//         }
//         i++;
//     }

//     var clear1 = document.createElement("div");
//     clear1.setAttribute("class","clear");
//     dyn.appendChild(clear1);

//     var title2 = document.createElement("div");
//     title2.setAttribute("class","chapter-title");
//     title2.innerHTML="Sleep Data";
//     dyn.appendChild(title2);

//     var i=0;
//     while(i<3)
//     {
//         if(!document.getElementById('timedrpact2'+i))
//         {
//             var subtitle = document.createElement("div");
//             subtitle.setAttribute("id","subtitle");
//             subtitle.setAttribute("class","subtitle");
//             subtitle.innerHTML=sleepData[i];
//             dyn.appendChild(subtitle);
            
//             // var clear2 = document.createElement("div");
//             // clear2.setAttribute("class","clear-2");
//             // subtitle.appendChild(clear2);

//             var ele2 = document.createElement("div");
//             ele2.setAttribute("id","timedrpact2"+i);
//             ele2.setAttribute("class","sleepData");
//             ele2.innerHTML=objArray[i];
//             subtitle.appendChild(ele2);

//             // var modify = document.createElement("div");
//             // modify.setAttribute("id","modify"+i);
//             // modify.setAttribute("class","modification");
//             // modify.innerHTML="modify";
//             // subtitle.appendChild(modify);
//         }
//         i++;
//     }
// };

