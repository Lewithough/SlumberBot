var json = '{"factors" : ["Stress", "Noise", "Temperature"], "sleepDuration":"8 hours", "sleepTime": "23:20 to 7:25", "sleepAwake": "2 times", "actions" : ["Sleep early", "Ban the phone", "Stretch for sleep", "Play less video games"]}'

$.ajax(
  {
    url: 'https://data.id.tue.nl/datasets/entity/249/item/',
    headers: {
      'api_token': 'xtWEHfLmLVVzcft63NOzqcV9hGBQPuz2Gj4Tk1Acpm1WZnoYziEZMiajnL88kE5S',
      'resource_id': 'y.liu10@student.tue.nl',
      'token': 'lyz95416'
    },
    type: 'GET',
    contentType: 'application/json',
    success: function(data) {
      console.log(data)
    },
    error: function(e) {
      console.log(e)
    }
  }
);
  
window.onload=function(){
    var dyn = document.getElementById('dynamic-factors'); 
    var obj = JSON.parse(json);

    var objArray = new Array();
    objArray[0] = obj.sleepDuration;
    objArray[1] = obj.sleepTime;
    objArray[2] = obj.sleepAwake;

    var sleepData = new Array();
    sleepData[0] = "Sleep Duration";
    sleepData[1] = "Sleep Time";
    sleepData[2] = "Awakenings";

    var title1 = document.createElement("div");
    title1.setAttribute("class","chapter-title");
    title1.innerHTML="Factors";
    dyn.appendChild(title1);

    var i=0;
    while(i<obj.factors.length)
    {
        if(!document.getElementById('timedrpact'+i))
        {
            var ele = document.createElement("div");
            var url = obj.factors[i] + '.html';
            console.log(url);
            ele.setAttribute("id","timedrpact"+i);
            ele.setAttribute("class","factors");
            ele.setAttribute("onclick","window.location.href='"+url+"'");
            ele.innerHTML=obj.factors[i];
            dyn.appendChild(ele);
        }
        i++;
    }

    var clear1 = document.createElement("div");
    clear1.setAttribute("class","clear");
    dyn.appendChild(clear1);

    var title3 = document.createElement("div");
    title3.setAttribute("class","chapter-title");
    title3.innerHTML="Actions";
    dyn.appendChild(title3);

    var i=0;
    while(i<obj.actions.length)
    {
        if(!document.getElementById('timedrpact3'+i))
        {
            var ele3 = document.createElement("div");
            // var url = obj.actions[i] + '.html';
            // console.log(url);
            ele3.setAttribute("id","timedrpact3"+i);
            ele3.setAttribute("class","actions");
            // ele.setAttribute("onclick","window.location.href='"+url+"'");
            ele3.innerHTML=obj.actions[i];
            dyn.appendChild(ele3);
        }
        i++;
    }

    var clear1 = document.createElement("div");
    clear1.setAttribute("class","clear");
    dyn.appendChild(clear1);

    var title2 = document.createElement("div");
    title2.setAttribute("class","chapter-title");
    title2.innerHTML="Sleep Data";
    dyn.appendChild(title2);

    var i=0;
    while(i<3)
    {
        if(!document.getElementById('timedrpact2'+i))
        {
            var subtitle = document.createElement("div");
            subtitle.setAttribute("id","subtitle");
            subtitle.setAttribute("class","subtitle");
            subtitle.innerHTML=sleepData[i];
            dyn.appendChild(subtitle);
            
            // var clear2 = document.createElement("div");
            // clear2.setAttribute("class","clear-2");
            // subtitle.appendChild(clear2);

            var ele2 = document.createElement("div");
            ele2.setAttribute("id","timedrpact2"+i);
            ele2.setAttribute("class","sleepData");
            ele2.innerHTML=objArray[i];
            subtitle.appendChild(ele2);

            // var modify = document.createElement("div");
            // modify.setAttribute("id","modify"+i);
            // modify.setAttribute("class","modification");
            // modify.innerHTML="modify";
            // subtitle.appendChild(modify);
        }
        i++;
    }
};

